function f1(a,b)
{
    return a+b;
}
console.log(f1(6,9));

var x = function(a,b)
{
    console.log(a+b);
   // return a+b;

}
//console.log(x(25,25));
x(5,3);

var val = new Number(251);
console.log(Number.MAX_VALUE);