var num =10;
if(num%2==0)
{
    console.log('number is even!');
}
else
{
    console.log('number is not even!');
}
var a = 10;
var b = 20;
console.log(a+b);