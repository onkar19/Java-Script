function add(a,b,callback){
console.log("sum of the given number are:"+(a+b));
callback();

}
function disp()
{
    console.log("my name is onkar");
}
add(2,3,disp);
//console.log(add(2,3,disp));