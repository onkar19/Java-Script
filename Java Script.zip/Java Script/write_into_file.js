var fs = require('fs');
let data = "Hello onkar!!";
fs.writeFile("write.txt",data,function(err){
    if(err)
    {
        console.log(err);

    }
    else{
        console.log(data);
    }
})