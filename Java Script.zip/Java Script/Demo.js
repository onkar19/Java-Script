let sale = true;
sale = false;
//var sale = true;
if(sale)
{
    console.log('welcome to javascript');
}
else{
    console.log('Hello java script');
}
//function f1(a,b)
var x = function(a,b)
{
    return a+b;
}
console.log(x(6,5));



