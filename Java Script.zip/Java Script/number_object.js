var val= Number.MAX_VALUE;
console.log(val);
var val = Number.MIN_VALUE;
console.log(val);