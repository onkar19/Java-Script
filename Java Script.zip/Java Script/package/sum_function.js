var x = require('./package/node_modules/lodash');
var m = [1,2,3,4,5,6,8];
console.log(x.sum(m));

var a = 6;
var b = 5;
console.log(x.subtract(a,b));