var week = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturdday','Sunday'];
console.log(week[0]); //line 1
console.log(week[5]);
console.log("size of array:"+week.length);

week.pop();
week.pop();
console.log(week);
week.push('saturday');
console.log(week);
week.unshift('sunday');
console.log(week);
week.splice(2,2,"onkargupta");/**deleting the element from position 2 and delete 2 element.
and adding element at index position
 */ 
console.log(week);
week.splice(2,2);
console.log(week); // deleting the element only.
week.length = 0; //this method is used to empty the array.
console.log(week);

