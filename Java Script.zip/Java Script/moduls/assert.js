var assert = require('assert');
//assert(5 > 7);

var x = 5;
var y = 5;
console.log(assert.deepEqual(x,y));