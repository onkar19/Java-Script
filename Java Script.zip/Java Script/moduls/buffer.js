var buf = Buffer.from('prt');
console.log(buf);
    
//convert string to binary.