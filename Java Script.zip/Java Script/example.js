let king = 'foo'    // line 1

if(true) {
	let king = 'bar'    //line 2
	if(true){
		let king = 'IncludeHelp'    //line 3
		console.log(king)
	}
}

if(true){           //block 1
	console.log("King at out side is:",king);
}
console.log(typeof('5' - 5));
console.log(typeof('5' + 5));