let tempConversion = function(celsius){
    fahrenheit = (celsius * 9/5) + 32   
    return fahrenheit 
}

todayTemp = tempConversion(45)
yesterdayTemp = tempConversion(38)
tomorrowTemp = tempConversion(40)
console.log(`Temp for 3 consecutive days are ${yesterdayTemp}F, ${todayTemp}F, ${tomorrowTemp}F`)
console.log("tomorrow temparature:"+fahrenheit); //priting the last one temparature
