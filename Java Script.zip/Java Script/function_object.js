let article = {
    author :'onkar',
    book :'java',
    wordCount : 200

}
let article2= {
    author : 'anant',
    book : 'c',
    wordCount : 400
}
let increaseCount = function(object) //function is manupulation the data.
{
    object.wordCount = object.wordCount+200;
}
increaseCount(article);
console.log(article);
increaseCount(article2);
console.log(article2);