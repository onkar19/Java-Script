let week;
week.forEach(function(days,index)
{
    console.log('day ${index+1} is',days);
})