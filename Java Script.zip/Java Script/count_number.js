var count;
console.log('starting loop');
for(count = 0; count<=10; count++)
{
    console.log('count is:'+count);
}
console.log('loop stoped');