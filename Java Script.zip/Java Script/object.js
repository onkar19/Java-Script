let object = {  //here object name in object,and we are creating a object.
    member: 'onkar',
    type : 'gupta'
}
console.log(object);
console.log('my name is:'+object.member+ " " +object.type);