var fs = require('fs');
fs.readFile('read.txt',"UTF8",function(err,data){
    if(err)
    {
        console.log(err);
    }
    else{
        console.log(data);
    }
})